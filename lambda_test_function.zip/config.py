
import  boto3

session = boto3.Session(
    aws_access_key_id="AKIAQ3EGUUFII4KRLSEB",
    aws_secret_access_key="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",
    region_name='us-east-1'
)

