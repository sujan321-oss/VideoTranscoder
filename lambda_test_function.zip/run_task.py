from clients import ecs_client


def run_task_videotranscoder ():
    cluster = "video_transcoder_cluster"
     
    response = ecs_client.create_task_set(
        cluster = cluster,
        
    )
    
    
    
